# Front end of blackjack

This is the front end repository for our game.  
Run the front end with `npm start`.
